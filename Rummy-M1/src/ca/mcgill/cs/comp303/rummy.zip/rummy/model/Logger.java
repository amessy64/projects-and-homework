package ca.mcgill.cs.comp303.rummy.model;

public interface Logger
{
	void printStatement(String pString);
}
