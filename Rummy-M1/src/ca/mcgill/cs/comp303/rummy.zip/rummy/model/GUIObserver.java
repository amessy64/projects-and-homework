package ca.mcgill.cs.comp303.rummy.model;

public interface GUIObserver
{

	void stateChanged(GameModel pModel);

}
